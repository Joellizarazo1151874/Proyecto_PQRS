const SignUp = () => {
  return <h1>Signup Page</h1>;
};

export default SignUp;
