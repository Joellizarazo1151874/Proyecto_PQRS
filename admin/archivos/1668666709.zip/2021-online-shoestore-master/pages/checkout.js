const Checkout = () => {
  return <h1>Checkout Page</h1>;
};

export default Checkout;
