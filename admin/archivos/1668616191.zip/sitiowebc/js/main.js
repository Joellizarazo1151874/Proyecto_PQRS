function saludar(nombre){
    alert ("Hola " + nombre);
    divTitulo.innerHTML = "BIENVENIDO "  + nombre;
}

function cambiarImagen(){
    imgLogo.src = "img/logo_sistemas.jpg"
}

function cambiarImagen2(){
    imgLogo.src = "img/logo_ufps.png"
}

function obtenerFechaModificacion(){
    var fecha = document.lastModified;
    divParrafos.innerHTML = fecha;
}

function validarDatos(){
    if (frmUsuario.email_usuario.value==""){
        divMensajes.innerHTML = "Error debe ingresar su email";
        frmUsuario.email_usuario.focus();
        return false;
    }
    
    frmUsuario.submit();
}